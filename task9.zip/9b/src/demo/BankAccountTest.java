package demo;

public class BankAccountTest {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(1000);

        Runnable depositTask = () -> {
            for (int i = 0; i < 5; i++) {
                account.deposit(100);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };

        Runnable withdrawTask = () -> {
            for (int i = 0; i < 5; i++) {
                account.withdraw(50);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };

        Thread user1 = new Thread(depositTask, "User1");
        Thread user2 = new Thread(withdrawTask, "User2");
        Thread user3 = new Thread(depositTask, "User3");
        Thread user4 = new Thread(withdrawTask, "User4");

        user1.start();
        user2.start();
        user3.start();
        user4.start();
    }
}
