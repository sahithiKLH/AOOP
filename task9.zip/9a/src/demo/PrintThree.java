package demo;

public class PrintThree implements Runnable {
    private NumberPrinter printer;

    public PrintThree(NumberPrinter printer) {
        this.printer = printer;
    }

    @Override
    public void run() {
        while (printer.hasNext()) {
            int number = printer.getNextNumber();
            if (number % 3 == 0 && number % 4 != 0 && number % 5 != 0) {
                System.out.println("Number " + number + " is divisible by 3");
            }
        }
    }
}
