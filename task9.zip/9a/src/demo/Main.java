package demo;

public class Main {
    public static void main(String[] args) {
        NumberPrinter printer = new NumberPrinter();

        Thread t1 = new Thread(new PrintTwo(printer));
        Thread t2 = new Thread(new PrintThree(printer));
        Thread t3 = new Thread(new PrintFour(printer));
        Thread t4 = new Thread(new PrintFive(printer));
        Thread t5 = new Thread(new PrintNumber(printer));

        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
    }
}
