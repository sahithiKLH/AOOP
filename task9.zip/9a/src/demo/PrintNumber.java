package demo;

public class PrintNumber implements Runnable {
    private NumberPrinter printer;

    public PrintNumber(NumberPrinter printer) {
        this.printer = printer;
    }

    @Override
    public void run() {
        while (printer.hasNext()) {
            int number = printer.getNextNumber();
            if (number % 2 != 0 && number % 3 != 0 && number % 4 != 0 && number % 5 != 0) {
                System.out.println("Number " + number);
            }
        }
    }
}
