package demo;

public class PrintFive implements Runnable {
    private NumberPrinter printer;

    public PrintFive(NumberPrinter printer) {
        this.printer = printer;
    }

    @Override
    public void run() {
        while (printer.hasNext()) {
            int number = printer.getNextNumber();
            if (number % 5 == 0) {
                System.out.println("Number " + number + " is divisible by 5");
            }
        }
    }
}
