package demo;

public class NumberPrinter {
    private int currentNumber = 1;

    public synchronized int getNextNumber() {
        return currentNumber++;
    }

    public synchronized boolean hasNext() {
        return currentNumber <= 15;
    }
}

