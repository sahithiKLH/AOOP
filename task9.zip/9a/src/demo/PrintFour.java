package demo;

public class PrintFour implements Runnable {
    private NumberPrinter printer;

    public PrintFour(NumberPrinter printer) {
        this.printer = printer;
    }

    @Override
    public void run() {
        while (printer.hasNext()) {
            int number = printer.getNextNumber();
            if (number % 4 == 0 && number % 5 != 0) {
                System.out.println("Number " + number + " is divisible by 4");
            }
        }
    }
}
