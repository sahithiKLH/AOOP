package demo;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class SharedBuffer {
    private BlockingQueue<String> queue = new LinkedBlockingQueue<>(10);

    public void putMessage(String message) throws InterruptedException {
        queue.put(message);
    }

    public String takeMessage() throws InterruptedException {
        return queue.take();
    }
}
